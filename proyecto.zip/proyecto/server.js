require('dotenv').config();  // Cargar variables de entorno
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');  // Importar CORS

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());  // Habilita CORS para todas las rutas

// Conexión a MongoDB Atlas
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    dbName: 'proyecto'  // Especificar el nombre de la base de datos
}).then(() => console.log("✅ Conectado a MongoDB Atlas"))
  .catch(err => console.error("❌ Error conectando a MongoDB Atlas:", err));

// Definir esquema y modelo
const schema = new mongoose.Schema({
    id_lector: { type: Number, required: true },
    codigo: { type: String, required: true },
    fecha_hora: { type: String, required: true },
    ubicacion: {
        latitud: { type: Number, required: true },
        longitud: { type: Number, required: true }
    }
});

// Cambiar el nombre de la colección a 'sensorRFID'
const Lectura = mongoose.model('SensorRFID', schema, 'sensorRFID');

// Ruta para recibir datos del ESP32
app.post('/api/datos', async (req, res) => {
    try {
        console.log("📥 Datos recibidos del ESP32:");
        console.log(JSON.stringify(req.body, null, 2)); // Imprime el JSON de la solicitud

        // Verificar que la ubicación esté correctamente recibida
        if (!req.body.ubicacion || typeof req.body.ubicacion.latitud === 'undefined' || typeof req.body.ubicacion.longitud === 'undefined') {
            console.log("⚠️ Error: No se recibió ubicación correctamente");
            return res.status(400).json({ error: "Faltan datos de ubicación (latitud y/o longitud)" });
        }

        // Crear un nuevo objeto con los datos recibidos
        const nuevoDato = new Lectura({
            id_lector: req.body.id_lector,
            codigo: req.body.codigo,
            fecha_hora: req.body.fecha_hora,
            ubicacion: req.body.ubicacion
        });

        // Guardar el nuevo dato en la base de datos
        await nuevoDato.save();
        console.log("✅ Datos guardados en MongoDB");

        // Responder al cliente
        res.json({ mensaje: "✅ Datos guardados correctamente" });
    } catch (error) {
        console.error("❌ Error al guardar datos:", error);
        res.status(500).json({ error: "Error al guardar los datos" });
    }
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
